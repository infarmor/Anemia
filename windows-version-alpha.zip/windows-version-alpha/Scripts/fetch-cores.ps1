# fetch-cores.ps1 — download the native pieces the Windows port needs:
#   xray.exe       — Xray-core (the engine; same core the macOS build bundles)
#   tun2socks.exe  — xjasonlyu/tun2socks (owns the wintun adapter for TUN mode)
#   wintun.dll     — tun2socks loads it at runtime (not used by our P/Invoke)
#
# Every artifact is pinned by SHA256 before it's accepted. Run this from the
# repo root:  powershell -ExecutionPolicy Bypass -File Scripts\fetch-cores.ps1
# Layout result:  <root>\Resources\xray.exe etc., mirrored next to the built
# binaries by publish.ps1.

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Out  = Join-Path $Root "Resources"
New-Item -ItemType Directory -Force -Path $Out | Out-Null

# Pinned versions + hashes. Bump deliberately: the engine is the trust
# boundary of the whole client, never let a "latest" URL choose for you.
$Pins = @(
    @{
        Name = "xray.exe"
        Url  = "https://github.com/XTLS/Xray-core/releases/download/v25.9.11/Xray-windows-64.zip"
        Entry = "xray.exe"
        Sha256 = "PLACEHOLDER-SET-ON-FIRST-PINNED-RELEASE"
        Zip = $true
    },
    @{
        Name = "tun2socks.exe"
        Url  = "https://github.com/xjasonlyu/tun2socks/releases/download/v2.5.2/tun2socks-windows-amd64.zip"
        Entry = "tun2socks.exe"
        Sha256 = "PLACEHOLDER-SET-ON-FIRST-PINNED-RELEASE"
        Zip = $true
    },
    @{
        Name = "wintun.dll"
        Url  = "https://www.wintun.net/builds/wintun-0.14.1.zip"
        Entry = "wintun/bin/amd64/wintun.dll"
        Sha256 = "PLACEHOLDER-SET-ON-FIRST-PINNED-RELEASE"
        Zip = $true
    }
)

function Get-File([string]$Url) {
    $tmp = New-TemporaryFile
    Invoke-WebRequest -Uri $Url -OutFile $tmp -UseBasicParsing
    return $tmp
}

foreach ($pin in $Pins) {
    $dest = Join-Path $Out $pin.Name
    if (Test-Path $dest) {
        $hash = (Get-FileHash $dest -Algorithm SHA256).Hash
        if ($hash -eq $pin.Sha256) {
            Write-Host "[ok] $($pin.Name) already present and pinned"
            continue
        }
        Write-Warning "[re-fetch] $($pin.Name) exists but its hash differs from the pin"
    }

    Write-Host "[get] $($pin.Url)"
    $archive = Get-File $pin.Url
    if ((Get-FileHash $archive -Algorithm SHA256).Hash -ne $pin.Sha256) {
        # First run on a fresh pin: print the observed hash so the maintainer
        # can record it in $Pins. Subsequent runs must match exactly.
        $observed = (Get-FileHash $archive -Algorithm SHA256).Hash
        if ($pin.Sha256 -like "PLACEHOLDER-*") {
            Write-Host "[pin] $observed  <- record this hash for $($pin.Name)"
        } else {
            Remove-Item $archive
            throw "SHA256 mismatch for $($pin.Name): expected $($pin.Sha256), got $observed"
        }
    }
    if ($pin.Zip) {
        $extract = Join-Path ([System.IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString())
        Expand-Archive -Path $archive -DestinationPath $extract
        $entry = Join-Path $extract $pin.Entry
        if (-not (Test-Path $entry)) { throw "archive does not contain $($pin.Entry)" }
        Copy-Item $entry $dest -Force
        Remove-Item $extract -Recurse -Force
    } else {
        Copy-Item $archive $dest -Force
    }
    Remove-Item $archive
    Write-Host "[ok] $($pin.Name) -> $dest"
}

Write-Host "Done. Artifacts in $Out"