using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.Json.Nodes;

namespace AnemiaHelper;

/// <summary>
/// Privileged tunnel supervisor. Protocol: one JSON line in → one JSON line
/// out per connection, commands: ping / start-tunnel / stop-tunnel / status.
///
/// Design notes (mirroring the macOS LoaderHelper):
///  • The wintun adapter is created and owned by tun2socks (--device anemia),
///    so this process never links wintun.dll itself — one less native
///    dependency to pin and update.
///  • The kill switch is fail-closed: the firewall's default outbound policy
///    is flipped to block BEFORE the allow rules exist, so a crash between
///    steps leaves the machine sealed. Every mutation is idempotent and
///    reversible by <see cref="TearDownTunnel"/>, which runs both on clean
///    stop and on process start (repairing after a crash mid-tunnel).
///  • A /32 route for the server's real IP via the ORIGINAL default gateway
///    is installed first, before the tunnel claims the default route — the
///    engine's own dial to the server must survive 0.0.0.0/0 being captured.
/// </summary>
internal static class Program
{
    private const string TunnelDevice = "anemia";
    private const string PipeName = "anemia-helper";
    private const string FirewallRulePrefix = "Anemia KS";

    private static readonly object Gate = new();
    private static Process? _tun2socks;
    private static bool _firewallArmed;
    private static (string RuleSuffix, string? ServerIp)? _tunnelState;
    private static readonly List<string> _addedRoutes = new();

    private static void Main()
    {
        // Repair pass: if a previous helper died mid-tunnel (crash, power
        // loss), its routes/firewall state is still armed — and _firewallArmed
        // is always false on a fresh boot, so TearDownTunnel alone would NOT
        // unseal the firewall. Disarm unconditionally: it's idempotent and
        // restores the Windows-default policy.
        TearDownTunnel();
        DisarmFirewall();

        while (true)
        {
            NamedPipeServerStream server;
            try
            {
                server = new NamedPipeServerStream(
                    PipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
            }
            catch (IOException)
            {
                // maxNumberOfServerInstances=1: a pipe already answers under
                // this name — a second helper instance would just sit here
                // forever serving nobody. Exit quietly instead.
                return;
            }
            using (server)
            {
                server.WaitForConnection();
                using var reader = new StreamReader(server, Encoding.UTF8);
                using var writer = new StreamWriter(server, new UTF8Encoding(false)) { AutoFlush = true };
                var line = reader.ReadLine();
                if (line is null) continue;
                var reply = Handle(line);
                writer.Write(reply + "\n");
            }
        }
    }

    private static string Handle(string line)
    {
        JsonObject? cmd;
        try
        {
            cmd = JsonNode.Parse(line) as JsonObject;
        }
        catch (System.Text.Json.JsonException)
        {
            return Reply(ok: false, "malformed command");
        }
        if (cmd is null) return Reply(ok: false, "malformed command");

        try
        {
            switch (cmd["cmd"]?.GetValue<string>())
            {
                case "ping":
                    return Reply(ok: true);
                case "status":
                    lock (Gate)
                        return Reply(ok: true, detail: _tunnelState is null ? "idle" : $"tunnel up (server {_tunnelState.Value.ServerIp ?? "?"})");
                case "start-tunnel":
                    return StartTunnel(cmd);
                case "stop-tunnel":
                    lock (Gate) TearDownTunnel();
                    return Reply(ok: true, detail: "tunnel down");
                default:
                    return Reply(ok: false, "unknown command");
            }
        }
        catch (Exception ex)
        {
            return Reply(ok: false, ex.Message);
        }
    }

    private static string Reply(bool ok, string? detail = null)
    {
        var node = new JsonObject { ["ok"] = ok };
        if (detail is not null) node["detail"] = detail;
        return node.ToJsonString();
    }

    private static string StartTunnel(JsonObject cmd)
    {
        var socksPort = cmd["socksPort"]?.GetValue<int>() ?? 0;
        var serverIp = cmd["serverIp"] is { } ip && ip.GetValue<string>().Length > 0
            ? ip.GetValue<string>() : null;
        var killSwitch = cmd["killSwitch"]?.GetValue<bool>() == true;
        if (socksPort is < 1 or > 65535) return Reply(ok: false, "bad socks port");

        lock (Gate)
        {
            if (_tunnelState is not null) TearDownTunnel();

            try
            {
                return StartTunnelInner(socksPort, serverIp, killSwitch);
            }
            catch (Exception ex)
            {
                // Any failure mid-sequence (firewall exec, adapter never
                // appeared, route add) must leave NOTHING armed: a machine
                // sealed by a half-built tunnel is worse than no tunnel.
                TearDownTunnel();
                return Reply(ok: false, ex.Message);
            }
        }
    }

    private static string StartTunnelInner(int socksPort, string? serverIp, bool killSwitch)
    {
        var tun2socks = ResolveTool("tun2socks.exe");
        if (tun2socks is null) return MissingToolReply("tun2socks.exe");

        // 0. Snapshot the ORIGINAL default gateway and interface BEFORE
        // any route changes; the server bypass hangs off it.
        var (originalGateway, originalIf) = DefaultGateway();
        if (originalGateway is null && serverIp is not null)
            return Reply(ok: false, "no default gateway — cannot install server bypass route");

        // 1. Fail-closed first: seal egress, then open exactly the holes
        // the tunnel needs. (Only when kill switch is requested.)
        if (killSwitch)
        {
            ArmFirewall(serverIp);
            _firewallArmed = true;
        }

        // 2. Spawn tun2socks on a free device name. It creates the wintun
        // adapter and pumps packets between it and our SOCKS inbound.
        _tun2socks = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = tun2socks,
                Arguments = $"--device {TunnelDevice} --proxy socks5://127.0.0.1:{socksPort} " +
                            "--loglevel warn",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            },
        };
        if (!_tun2socks.Start())
        {
            return Reply(ok: false, "tun2socks failed to start");
        }
        // Drain both pipes: redirected output nobody reads fills the 4 KB
        // pipe buffer, and then tun2socks blocks forever on its next log
        // line — a tunnel that dies the first time it has something to say.
        _tun2socks.BeginOutputReadLine();
        _tun2socks.BeginErrorReadLine();

        // 3. Address the adapter. tun2socks needs a moment to create it.
        var addressed = false;
        for (var attempt = 0; attempt < 20 && !addressed; attempt++)
        {
            Thread.Sleep(250);
            addressed = Run($"interface ip set address name=\"{TunnelDevice}\" source=static addr=198.18.0.1 mask=255.255.255.0") is null;
        }
        if (!addressed)
        {
            return Reply(ok: false, $"adapter '{TunnelDevice}' never appeared");
        }

        // 4. Routes, most-critical first: the server bypass /32 via the
        // original gateway, then the default route via the tunnel.
        // Gateway for the tunnel is 198.18.0.2 (tun2socks answers there
        // out of the box on a /24 with our .1).
        if (serverIp is not null && originalGateway is { } gw)
        {
            AddRoute(serverIp, "255.255.255.255", gw, originalIf);
        }
        AddRoute("0.0.0.0", "0.0.0.0", "198.18.0.2", TunnelDevice, metric: 1);

        // 5. Point system DNS at the tunnel: the engine hijacks :53
        // (hijackDns) and resolves via DoH through the proxy, so ISP
        // poisoning is out of the loop entirely. Best-effort: if it fails,
        // lookups fall to the physical adapter's resolver — degraded, not
        // broken.
        Run($"interface ip set dns name=\"{TunnelDevice}\" source=static addr=198.18.0.2");

        _tunnelState = (TunnelDevice, serverIp);
        return Reply(ok: true, detail: "tunnel up");
    }

    private static string MissingToolReply(string tool) =>
        Reply(ok: false, $"{tool} not found next to the app (see Scripts/fetch-cores.ps1)");

    /// <summary>Full teardown, idempotent. Order matters: kill the pump first
    /// (its exit removes the wintun adapter and its routes), then the static
    /// routes we added, then restore the firewall LAST — restoring it first
    /// would briefly expose traffic on a still-routed tunnel.</summary>
    private static void TearDownTunnel()
    {
        lock (Gate)
        {
            if (_tun2socks is { } proc)
            {
                try
                {
                    if (!proc.HasExited) proc.Kill(entireProcessTree: true);
                }
                catch (InvalidOperationException) { }
                catch (SystemException) { }
                proc.Dispose();
                _tun2socks = null;
            }
            foreach (var deleteArgs in _addedRoutes)
            {
                RunRoute(deleteArgs); // best-effort
            }
            _addedRoutes.Clear();
            if (_firewallArmed)
            {
                DisarmFirewall();
                _firewallArmed = false;
            }
            _tunnelState = null;
        }
    }

    // ── Route plumbing ────────────────────────────────────────────────────

    private static void AddRoute(string dest, string mask, string gateway, string? interfaceName, int metric = 1)
    {
        // route.exe, not netsh: the route table is read back via
        // `route print -4` in DefaultGateway, so one tool owns both
        // directions. Interface is addressed by index; resolve it from the
        // interface name when we have one.
        string? ifPart = null;
        if (interfaceName is { } name)
        {
            var index = NetworkInterface.GetAllNetworkInterfaces()
                .FirstOrDefault(n => n.Name == name)
                ?.GetIPProperties().GetIPv4Properties()?.Index;
            if (index is { } idx) ifPart = $" if {idx}";
        }
        // NOT persistent (-p omitted): a crash must not leave a default
        // route pointing at a dead tunnel across reboots. Crash-orphaned
        // non-persistent routes die with the adapter; the firewall seal is
        // disarmed by the boot-repair pass instead.
        var args = $"add {dest} mask {mask} {gateway} metric {metric}{ifPart}";
        var error = RunRoute(args);
        if (error is null) _addedRoutes.Add($"delete {dest} mask {mask}");
        // A route that already exists from a crashed previous run is fine.
        else if (!error.Contains("already exists", StringComparison.OrdinalIgnoreCase)
                 && !error.Contains("object already", StringComparison.OrdinalIgnoreCase))
            throw new IOException($"route add failed: {error}");
    }

    /// <summary>(gateway IP, interface name) of the current default route —
    /// the physical one, before the tunnel exists. Parsed from `route print`
    /// because .NET has no managed route-table API.</summary>
    private static (string? Gateway, string? Interface) DefaultGateway()
    {
        string output;
        using (var proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "route",
                Arguments = "print -4",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            },
        })
        {
            proc.Start();
            output = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit(10000);
        }
        string? gateway = null, interfaceIp = null;
        foreach (var raw in output.Split('\n'))
        {
            var tokens = raw.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            // route print columns: Destination Netmask Gateway Interface Metric
            if (tokens.Length >= 4 && tokens[0] == "0.0.0.0" && tokens[1] == "0.0.0.0")
            {
                gateway = tokens[2];
                interfaceIp = tokens[3];
                break;
            }
        }
        if (gateway is null || interfaceIp is null) return (null, null);
        var name = NetworkInterface.GetAllNetworkInterfaces()
            .FirstOrDefault(n => n.GetIPProperties()
                .UnicastAddresses.Any(a => a.Address.ToString() == interfaceIp))?.Name;
        return (gateway, name);
    }

    // ── Firewall kill switch ──────────────────────────────────────────────

    private static void ArmFirewall(string? serverIp)
    {
        // Default-deny outbound in ALL profiles, always, even on public ones.
        Exec("advfirewall set allprofiles firewallpolicy blockinboundalways,blockoutbound");
        Exec($"advfirewall firewall add rule name=\"{FirewallRulePrefix} loopback\" dir=out action=allow remoteip=127.0.0.0/8");
        foreach (var exe in new[] { "xray.exe", "tun2socks.exe", "Anemia.exe" })
        {
            var path = ResolveTool(exe);
            if (path is not null)
                Exec($"advfirewall firewall add rule name=\"{FirewallRulePrefix} {exe}\" dir=out action=allow program=\"{path}\"");
        }
        // The server's own IP must stay dialable even before the TUN is up —
        // that IS the escape hatch that makes fail-closed survivable.
        if (serverIp is not null)
            Exec($"advfirewall firewall add rule name=\"{FirewallRulePrefix} server\" dir=out action=allow remoteip={serverIp}");
        // Loopback DNS hijack target + DHCP renewals need UDP/53 & 67/68 out
        // the physical net only when they come from Windows itself; keep it
        // strict: DHCP only.
        Exec("advfirewall firewall add rule name=\"Anemia KS dhcp\" dir=out action=allow protocol=udp remoteport=67,68");
    }

    private static void DisarmFirewall()
    {
        // Windows defaults: outbound allowed. Delete our rules, then restore
        // policy — deleting first avoids a window where allow rules are gone
        // but policy still blocks.
        foreach (var name in new[]
                 {
                     $"{FirewallRulePrefix} loopback", $"{FirewallRulePrefix} server",
                     $"{FirewallRulePrefix} dhcp", $"{FirewallRulePrefix} xray.exe",
                     $"{FirewallRulePrefix} tun2socks.exe", $"{FirewallRulePrefix} Anemia.exe",
                 })
        {
            Exec($"advfirewall firewall delete rule name=\"{name}\"");
        }
        Exec("advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound");
    }

    // ── Subprocess + tooling helpers ──────────────────────────────────────

    /// <summary>Run route.exe, return null on success or the output text.</summary>
    private static string? RunRoute(string routeArgs)
    {
        using var proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "route",
                Arguments = routeArgs,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            },
        };
        proc.Start();
        var output = proc.StandardOutput.ReadToEnd() + proc.StandardError.ReadToEnd();
        proc.WaitForExit(15000);
        return proc.ExitCode == 0 ? null : output.Trim();
    }

    /// <summary>Run netsh, return null on success or the stderr text.</summary>
    private static string? Run(string netshArgs)
    {
        using var proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "netsh",
                Arguments = netshArgs,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            },
        };
        proc.Start();
        var output = proc.StandardOutput.ReadToEnd() + proc.StandardError.ReadToEnd();
        proc.WaitForExit(15000);
        return proc.ExitCode == 0 ? null : output.Trim();
    }

    private static void Exec(string netshArgs)
    {
        var err = Run(netshArgs);
        if (err is not null) throw new IOException($"netsh {netshArgs.Split(' ')[0]}: {err}");
    }

    /// <summary>Locate a bundled tool: sibling Resources\ dir of the app that
    /// launched us, then our own directory.</summary>
    private static string? ResolveTool(string fileName)
    {
        foreach (var dir in new[]
                 {
                     Path.Combine(AppContext.BaseDirectory, "Resources"),
                     AppContext.BaseDirectory,
                     Path.Combine(AppContext.BaseDirectory, ".."),
                 })
        {
            try
            {
                var candidate = Path.GetFullPath(Path.Combine(dir, fileName));
                if (File.Exists(candidate)) return candidate;
            }
            catch (IOException) { }
        }
        return null;
    }
}