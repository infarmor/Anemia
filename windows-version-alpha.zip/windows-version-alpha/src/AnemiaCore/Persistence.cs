using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace AnemiaCore;

/// <summary>
/// The full persisted client state: manually-added servers, subscriptions, the
/// current selection, and anti-DPI options.
/// </summary>
public sealed class PersistedState
{
    public List<ProxyServer> Servers { get; set; } = new();
    public List<Subscription> Subscriptions { get; set; } = new();
    public Guid? SelectedServerId { get; set; }
    public AntiCensorshipOptions Anti { get; set; } = new();
    public bool KillSwitchEnabled { get; set; }
    public MaskingProfile MaskingProfile { get; set; } = MaskingProfile.Balanced;
    public bool AutoConnectOnLaunch { get; set; }
    /// <summary>Coexist mode: set the Windows system proxy to the engine while
    /// connected, so browsers route through Anemia alongside another VPN.</summary>
    public bool SystemProxyEnabled { get; set; } = true;
    /// <summary>Refresh subscriptions automatically: once shortly after launch,
    /// then every 6 hours. Keeps expiring/rotating server lists current.</summary>
    public bool SubscriptionAutoRefresh { get; set; } = true;
    /// <summary>
    /// Masking profile (by ProxyServer.IdentityKey) that was learned to keep a
    /// given server's traffic flowing, from adaptive escalation during
    /// recovery. Reused on the next connect to that server so it starts from
    /// the obfuscation it actually needs, not the global default.
    /// </summary>
    public Dictionary<string, string> LearnedMasking { get; set; } = new();

    public PersistedState() { }

    /// <summary>Lenient decoding: missing or malformed fields fall back to
    /// defaults so a schema change never discards a user's saved servers.
    /// Collections decode element-by-element: a single poisoned entry drops
    /// only itself, not the whole list. Returns null when the store is so
    /// corrupt that defaults should replace it (the persistence layer then
    /// backs the raw bytes up first).</summary>
    public static PersistedState? FromJson(JsonNode? root)
    {
        if (root is not JsonObject obj) return null;
        var state = new PersistedState();

        state.Servers = LenientArray(obj, "servers", ProxyServerFromJson);
        state.Subscriptions = LenientArray(obj, "subscriptions", static n =>
        {
            if (n is not JsonObject s) return null;
            var sub = new Subscription
            {
                Id = s["id"] is JsonValue sid && sid.TryGetValue<Guid>(out var sg) ? sg : Guid.NewGuid(),
                Name = s["name"] as JsonValue is JsonValue nv && nv.TryGetValue<string>(out var sn) ? sn : "",
                Url = s["url"] as JsonValue is JsonValue uv && uv.TryGetValue<string>(out var su) ? su : "",
                LastUpdated = s["lastUpdated"] is JsonValue lv && lv.TryGetValue<DateTimeOffset>(out var ld) ? ld : null,
                Servers = LenientArray(s, "servers", ProxyServerFromJson),
            };
            return sub;
        });
        if (obj["selectedServerID"] is JsonValue sel && sel.TryGetValue<Guid>(out var selId))
            state.SelectedServerId = selId;
        state.Anti = AntiCensorshipOptions.FromJson(obj["anti"]);
        if (obj["killSwitchEnabled"] is JsonValue ks) state.KillSwitchEnabled = AntiCensorshipOptions.TryBool(ks, false);
        if (obj["maskingProfile"] is JsonValue mp &&
            mp.TryGetValue<string>(out var mpStr) &&
            Enum.TryParse<MaskingProfile>(mpStr, ignoreCase: true, out var mpEnum))
            state.MaskingProfile = mpEnum;
        if (obj["autoConnectOnLaunch"] is JsonValue ac) state.AutoConnectOnLaunch = AntiCensorshipOptions.TryBool(ac, false);
        if (obj["systemProxyEnabled"] is JsonValue sp) state.SystemProxyEnabled = AntiCensorshipOptions.TryBool(sp, true);
        if (obj["subscriptionAutoRefresh"] is JsonValue sa) state.SubscriptionAutoRefresh = AntiCensorshipOptions.TryBool(sa, true);
        if (obj["learnedMasking"] is JsonObject lm)
        {
            foreach (var (k, v) in lm)
                if (v is JsonValue vv && vv.TryGetValue<string>(out var str))
                    state.LearnedMasking[k] = str;
        }
        return state;
    }

    /// <summary>Decode a ProxyServer entry leniently: unknown enum raw values
    /// or type drift drop the single entry instead of the whole store.</summary>
    internal static ProxyServer? ProxyServerFromJson(JsonNode? node)
    {
        if (node is not JsonObject o) return null;
        try
        {
            var server = new ProxyServer();
            if (o["id"] is JsonValue iv && iv.TryGetValue<Guid>(out var id)) server.Id = id;
            if (o["name"] is JsonValue nv2 && nv2.TryGetValue<string>(out var name)) server.Name = name;
            if (o["proto"] is JsonValue pv && pv.TryGetValue<string>(out var proto) &&
                Wire.ParseProtocol(proto) is { } p) server.Proto = p;
            else return null; // protocol is load-bearing; anything else is recoverable
            if (o["address"] is JsonValue av && av.TryGetValue<string>(out var addr)) server.Address = addr;
            if (o["port"] is JsonValue pv2 && pv2.TryGetValue<int>(out var port)) server.Port = port;
            if (o["credential"] is JsonValue cv && cv.TryGetValue<string>(out var cred)) server.Credential = cred;
            if (o["method"] is JsonValue mv && mv.TryGetValue<string>(out var m)) server.Method = m;
            if (o["alterId"] is JsonValue av2 && av2.TryGetValue<int>(out var aid)) server.AlterId = aid;
            if (o["vmessCipher"] is JsonValue vc && vc.TryGetValue<string>(out var scy)) server.VmessCipher = scy;
            if (o["network"] is JsonValue nw && nw.TryGetValue<string>(out var net) &&
                Wire.ParseNetwork(net) is { } n) server.Network = n;
            if (o["security"] is JsonValue sv && sv.TryGetValue<string>(out var sec) &&
                Wire.ParseSecurity(sec) is { } sec2) server.Security = sec2;
            if (o["sni"] is JsonValue sni && sni.TryGetValue<string>(out var sniS)) server.Sni = sniS;
            if (o["alpn"] is JsonArray alpnArr)
                server.Alpn = alpnArr.OfType<JsonValue>()
                    .Select(a => a.TryGetValue<string>(out var x) ? x : "")
                    .Where(x => x.Length > 0).ToList();
            if (o["fingerprint"] is JsonValue fp && fp.TryGetValue<string>(out var fpS)) server.Fingerprint = fpS;
            if (o["allowInsecure"] is JsonValue ai) server.AllowInsecure = AntiCensorshipOptions.TryBool(ai, false);
            if (o["realityPublicKey"] is JsonValue pk && pk.TryGetValue<string>(out var pkS)) server.RealityPublicKey = pkS;
            if (o["realityShortId"] is JsonValue sid && sid.TryGetValue<string>(out var sidS)) server.RealityShortId = sidS;
            if (o["realitySpiderX"] is JsonValue spx && spx.TryGetValue<string>(out var spxS)) server.RealitySpiderX = spxS;
            if (o["flow"] is JsonValue fl && fl.TryGetValue<string>(out var flS)) server.Flow = flS;
            if (o["path"] is JsonValue pth && pth.TryGetValue<string>(out var pthS)) server.Path = pthS;
            if (o["host"] is JsonValue hv && hv.TryGetValue<string>(out var hS)) server.Host = hS;
            if (o["headerType"] is JsonValue ht && ht.TryGetValue<string>(out var htS)) server.HeaderType = htS;
            if (o["grpcMultiMode"] is JsonValue gm) server.GrpcMultiMode = AntiCensorshipOptions.TryBool(gm, false);
            return server;
        }
        catch (InvalidOperationException)
        {
            return null;
        }
        catch (FormatException)
        {
            return null;
        }
    }

    private static List<T> LenientArray<T>(JsonObject obj, string key, Func<JsonNode?, T?> map) where T : class
    {
        var result = new List<T>();
        if (obj[key] is JsonArray arr)
        {
            foreach (var entry in arr)
                if (map(entry) is { } mapped) result.Add(mapped);
        }
        return result;
    }

    public JsonObject ToJson()
    {
        var obj = new JsonObject
        {
            ["servers"] = ToJsonArray(Servers),
            ["subscriptions"] = ToJsonArray(Subscriptions.Select(static s => new JsonObject
            {
                ["id"] = s.Id,
                ["name"] = s.Name,
                ["url"] = s.Url,
                ["lastUpdated"] = s.LastUpdated?.ToString("O"),
                ["servers"] = ToJsonArray(s.Servers),
            })),
            ["selectedServerID"] = SelectedServerId?.ToString(),
            ["anti"] = Anti.ToJson(),
            ["killSwitchEnabled"] = KillSwitchEnabled,
            ["maskingProfile"] = MaskingProfile.ToString(),
            ["autoConnectOnLaunch"] = AutoConnectOnLaunch,
            ["systemProxyEnabled"] = SystemProxyEnabled,
            ["subscriptionAutoRefresh"] = SubscriptionAutoRefresh,
        };
        var learned = new JsonObject();
        foreach (var (k, v) in LearnedMasking) learned[k] = v;
        obj["learnedMasking"] = learned;
        return obj;
    }

    private static JsonArray ToJsonArray(IEnumerable<JsonObject> entries)
    {
        var arr = new JsonArray();
        foreach (var s in entries) arr.Add(s);
        return arr;
    }

    private static JsonArray ToJsonArray(IEnumerable<ProxyServer> servers)
    {
        var arr = new JsonArray();
        foreach (var s in servers)
        {
            arr.Add(new JsonObject
            {
                ["id"] = s.Id,
                ["name"] = s.Name,
                ["proto"] = Wire.Name(s.Proto),
                ["address"] = s.Address,
                ["port"] = s.Port,
                ["credential"] = s.Credential,
                ["method"] = s.Method,
                ["alterId"] = s.AlterId,
                ["vmessCipher"] = s.VmessCipher,
                ["network"] = Wire.Name(s.Network),
                ["security"] = Wire.Name(s.Security),
                ["sni"] = s.Sni,
                ["alpn"] = new JsonArray(s.Alpn.Select(a => (JsonNode?)a).ToArray()),
                ["fingerprint"] = s.Fingerprint,
                ["allowInsecure"] = s.AllowInsecure,
                ["realityPublicKey"] = s.RealityPublicKey,
                ["realityShortId"] = s.RealityShortId,
                ["realitySpiderX"] = s.RealitySpiderX,
                ["flow"] = s.Flow,
                ["path"] = s.Path,
                ["host"] = s.Host,
                ["headerType"] = s.HeaderType,
                ["grpcMultiMode"] = s.GrpcMultiMode,
            });
        }
        return arr;
    }

    /// <summary>Every selectable server: manual entries first, then
    /// subscription servers.</summary>
    [JsonIgnore]
    public IEnumerable<ProxyServer> AllServers => Servers.Concat(Subscriptions.SelectMany(s => s.Servers));

    public ProxyServer? ServerWithId(Guid id) => AllServers.FirstOrDefault(s => s.Id == id);
}

/// <summary>
/// Reads/writes <see cref="PersistedState"/> as JSON on disk. Writes atomically
/// so a crash mid-save can't corrupt the store.
/// </summary>
public sealed class StatePersistence
{
    private static readonly JsonSerializerOptions WriteOptions = new() { WriteIndented = true };

    public string FilePath { get; }

    public StatePersistence(string filePath) => FilePath = filePath;

    /// <summary>Default location: %APPDATA%\Anemia\state.json.</summary>
    public static string DefaultPath()
    {
        var baseDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        if (string.IsNullOrEmpty(baseDir)) baseDir = Environment.CurrentDirectory;
        return Path.Combine(baseDir, "Anemia", "state.json");
    }

    /// <summary>
    /// Load state, returning an empty default if the file is absent/unreadable.
    /// A malformed or schema-drifted file is backed up first — the lenient
    /// decoder never throws on field mismatches (it falls back per-field), so a
    /// silent data loss must be detected by comparing the raw JSON with what
    /// the decode recovered.
    /// </summary>
    public PersistedState Load()
    {
        byte[] data;
        try
        {
            data = File.ReadAllBytes(FilePath);
        }
        catch (IOException)
        {
            return new PersistedState();
        }
        catch (UnauthorizedAccessException)
        {
            return new PersistedState();
        }

        PersistedState? decoded = null;
        JsonObject? raw = null;
        try
        {
            raw = JsonNode.Parse(data) as JsonObject;
            decoded = PersistedState.FromJson(raw);
        }
        catch (JsonException)
        {
            decoded = null;
        }

        // Schema drift detector: the raw store still carries entries in some
        // collection, but the decode recovered fewer of them (or none — or
        // failed outright) → previous contents are about to be lost. Counts
        // are compared, not just emptiness. Every persisted collection is
        // checked, not just `servers`.
        var droppedEntries = false;
        if (raw is not null)
        {
            static int? RawCount(JsonNode? v)
            {
                if (v is null) return null;
                if (v is JsonArray a) return a.Count;
                if (v is JsonObject o) return o.Count;
                return 1;
            }
            int? DecodedCount(int actual) => decoded is null ? 0 : actual;

            if (RawCount(raw["servers"]) is { } n1)
                droppedEntries = droppedEntries || (decoded?.Servers.Count ?? 0) < n1;
            if (RawCount(raw["subscriptions"]) is { } n2)
                droppedEntries = droppedEntries || (decoded?.Subscriptions.Count ?? 0) < n2;
            if (RawCount(raw["learnedMasking"]) is { } n3)
                droppedEntries = droppedEntries || (decoded?.LearnedMasking.Count ?? 0) < n3;
            _ = DecodedCount(0);
        }
        if (decoded is null || droppedEntries)
        {
            // Millisecond timestamp: a same-second collision would silently
            // overwrite an earlier backup.
            var backup = Path.Combine(
                Path.GetDirectoryName(FilePath)!,
                $"{Path.GetFileNameWithoutExtension(FilePath)}.json.corrupt-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}.bak");
            try
            {
                File.WriteAllBytes(backup, data);
            }
            catch (IOException)
            {
                // recovery must never crash the app
            }
            catch (UnauthorizedAccessException)
            {
            }
            PruneCorruptBackups();
        }
        return decoded ?? new PersistedState();
    }

    public void Save(PersistedState state)
    {
        var dir = Path.GetDirectoryName(FilePath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        // Write-then-rename: the closest portable equivalent of an atomic
        // file write, so a crash mid-save can't corrupt the store.
        var tmp = FilePath + ".tmp";
        File.WriteAllText(tmp, state.ToJson().ToJsonString(WriteOptions));
        if (File.Exists(FilePath)) File.Replace(tmp, FilePath, null);
        else File.Move(tmp, FilePath);
    }

    /// <summary>A persistently poisoned store re-enters the backup path on
    /// every app launch, each run dropping a fresh timestamped .corrupt-*.bak
    /// next to the state file — unbounded clutter. Keep only the newest few
    /// and delete the rest (best effort; failure to prune must never fail the
    /// load).</summary>
    private void PruneCorruptBackups(int kept = 3)
    {
        try
        {
            var dir = Path.GetDirectoryName(FilePath);
            if (dir is null) return;
            var baseName = Path.GetFileNameWithoutExtension(FilePath);
            var backups = Directory.GetFiles(dir, $"{baseName}.json.corrupt-*.bak")
                .OrderByDescending(static f => f, StringComparer.Ordinal) // newest (largest ms stamp) first
                .ToList();
            for (var i = kept; i < backups.Count; i++)
            {
                try { File.Delete(backups[i]); } catch (IOException) { }
            }
        }
        catch (IOException)
        {
        }
    }
}