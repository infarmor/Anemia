using System.Net;
using System.Net.Sockets;

namespace AnemiaCore;

/// <summary>
/// Direct (getaddrinfo) DNS resolution used OUTSIDE the tunnel: the VPN
/// server's own address must be known before the engine can provide any
/// tunneled answers, so its resolution can never depend on the proxy.
/// </summary>
public static class DirectResolver
{
    /// <summary>
    /// Whether the string is already a dotted-quad IPv4 literal. Octets must
    /// be plain ASCII digits (a leading "+4" must not parse), each 0…255, and
    /// exactly four of them — "1..2.3" / "1.2.3." must not pass.
    /// </summary>
    public static bool IsIPv4(string s)
    {
        var parts = s.Split('.');
        return parts.Length == 4 && parts.All(part =>
            part.Length > 0 &&
            part.All(c => c is >= '0' and <= '9') &&
            int.TryParse(part, out var v) && v is >= 0 and <= 255);
    }

    /// <summary>
    /// Whether the address falls inside 198.18.0.0/15 — the fake-IP pool that
    /// sing-box/clash/mihomo clients hand out from their DNS. A resolution
    /// landing there is never a real destination. Only a literal dotted-quad
    /// can be a fake-IP answer: a hostname that merely starts with "198.18."
    /// (e.g. 198.18.mirror.example.com) is a real, resolvable domain.
    /// </summary>
    public static bool IsFakeIP(string s)
    {
        if (!s.All(c => (c >= '0' && c <= '9') || c == '.')) return false;
        return s.StartsWith("198.18.") || s.StartsWith("198.19.");
    }

    /// <summary>
    /// Resolve a hostname to IPv4 addresses via the system resolver — no
    /// tunnel involvement. Fake-IP answers are filtered out so a concurrently
    /// running fake-IP VPN can't poison the pin.
    /// </summary>
    public static List<string> IPv4(string host)
    {
        if (IsIPv4(host) || IsFakeIP(host)) return new List<string>();
        try
        {
            // AddressFamily.InterNetwork restricts the query to A records.
            var entries = Dns.GetHostEntry(host, AddressFamily.InterNetwork).AddressList;
            var ips = new List<string>();
            foreach (var entry in entries)
            {
                var ip = entry.ToString();
                if (!ips.Contains(ip) && !IsFakeIP(ip)) ips.Add(ip);
            }
            return ips;
        }
        catch (SocketException)
        {
            return new List<string>();
        }
        catch (ArgumentException)
        {
            return new List<string>();
        }
    }
}