using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace AnemiaCore;

/// <summary>Errors surfaced while parsing share links or subscriptions.</summary>
public enum ParseErrorKind
{
    UnsupportedScheme,
    MalformedUri,
    MissingField,
    InvalidBase64,
    EmptyInput,
    /// <summary>The link names a transport the parser knows but the bundled
    /// engine no longer ships — e.g. xhttp/splithttp.</summary>
    UnsupportedTransport,
}

/// <summary>Exception form of <see cref="ParseErrorKind"/>; equality is by
/// (kind, detail) so tests can assert like the Swift enum did.</summary>
public sealed class ParseErrorException : Exception, IEquatable<ParseErrorException>
{
    public ParseErrorKind Kind { get; }
    public string Detail { get; }

    public ParseErrorException(ParseErrorKind kind, string detail = "")
    {
        Kind = kind;
        Detail = detail;
    }

    public bool Equals(ParseErrorException? other) =>
        other is not null && other.Kind == Kind && other.Detail == Detail;
    public override bool Equals(object? obj) => Equals(obj as ParseErrorException);
    public override int GetHashCode() => HashCode.Combine(Kind, Detail);
    public override string Message =>
        string.IsNullOrEmpty(Detail) ? Kind.ToString() : $"{Kind}: {Detail}";
}

/// <summary>
/// Parses proxy share links into the canonical <see cref="ProxyServer"/> model.
/// Supported schemes: vless://, vmess://, ss://, trojan://. The parser is
/// deliberately lenient about missing/optional query fields so that real-world
/// links from a range of panels import cleanly.
/// </summary>
public static class ShareLinkParser
{
    /// <summary>Parse a single share link. Whitespace is trimmed first.</summary>
    public static ProxyServer Parse(string raw)
    {
        var link = raw.Trim();
        if (link.Length == 0) throw new ParseErrorException(ParseErrorKind.EmptyInput);

        int schemeEnd = link.IndexOf("://", StringComparison.Ordinal);
        if (schemeEnd < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
        var scheme = link[..schemeEnd].ToLowerInvariant();

        return scheme switch
        {
            "vless" => ParseVless(link),
            "trojan" => ParseTrojan(link),
            "vmess" => ParseVmess(link),
            "ss" => ParseShadowsocks(link),
            _ => throw new ParseErrorException(ParseErrorKind.UnsupportedScheme, scheme),
        };
    }

    // MARK: - VLESS

    private static ProxyServer ParseVless(string link)
    {
        var uri = new UriParts(link);
        if (string.IsNullOrEmpty(uri.UserInfo)) throw new ParseErrorException(ParseErrorKind.MissingField, "uuid");
        if (uri.Host is null || uri.Port is null) throw new ParseErrorException(ParseErrorKind.MissingField, "host/port");
        ValidatePort(uri.Port.Value, link);

        var q = uri.Query;
        var security = SecurityValue(q, fallback: StreamSecurity.None);
        var server = new ProxyServer(
            name: uri.Fragment ?? uri.Host!,
            proto: ProxyProtocol.Vless,
            address: uri.Host!,
            port: uri.Port.Value,
            credential: uri.UserInfo!,
            network: NetworkTypeOf(q),
            security: security,
            flow: q.GetValueOrDefault("flow") is { Length: > 0 } flow ? flow : null
        )
        { Security = security };
        ApplyStreamParams(server, q);
        return server;
    }

    // MARK: - Trojan

    private static ProxyServer ParseTrojan(string link)
    {
        var uri = new UriParts(link);
        if (string.IsNullOrEmpty(uri.UserInfo)) throw new ParseErrorException(ParseErrorKind.MissingField, "password");
        if (uri.Host is null || uri.Port is null) throw new ParseErrorException(ParseErrorKind.MissingField, "host/port");
        ValidatePort(uri.Port.Value, link);

        var q = uri.Query;
        // Trojan defaults to TLS even when `security` is omitted.
        var security = SecurityValue(q, fallback: StreamSecurity.Tls);
        // No `flow`: the XTLS flow field exists only for VLESS — a trojan
        // link's stray flow= param (panels emit it gratuitously) would reach
        // the trojan outbound where Xray rejects unknown flow values at
        // config validation.
        var server = new ProxyServer(
            name: uri.Fragment ?? uri.Host!,
            proto: ProxyProtocol.Trojan,
            address: uri.Host!,
            port: uri.Port.Value,
            credential: uri.UserInfo!,
            network: NetworkTypeOf(q),
            security: security
        );
        ApplyStreamParams(server, q);
        return server;
    }

    /// <summary>Case-insensitive security= parsing: real-world links carry TLS,
    /// Reality, REALITY…. A case-sensitive rawValue lookup silently fell back
    /// to none — a TLS server parsed as plaintext that could never handshake,
    /// with no diagnostic.</summary>
    private static StreamSecurity SecurityValue(Dictionary<string, string> q, StreamSecurity fallback)
    {
        var raw = q.GetValueOrDefault("security");
        if (string.IsNullOrEmpty(raw)) return fallback;
        return Wire.ParseSecurity(raw) ?? fallback;
    }

    /// <summary>Ports outside 1…65535 parse fine as integers but reach the
    /// engine config verbatim, where the outbound bind fails at start with an
    /// opaque error — reject at the source instead.</summary>
    private static void ValidatePort(int port, string link)
    {
        if (port is < 1 or > 65535) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
    }

    // MARK: - VMess

    private static ProxyServer ParseVmess(string link)
    {
        // Some generators append a #remarks fragment (or a query) to the
        // base64 body: vmess://BASE64#name. The base64 alphabet never contains
        // '#' or '?', so anything from the first one is decoration — but a
        // lenient decode ignores unknown characters, so ASCII letters of a
        // fragment name would be swallowed into the payload, shift the stream
        // alignment and corrupt the JSON. Peel it first, exactly like the ss
        // branch does.
        var body = link["vmess://".Length..];
        int cut = body.AsSpan().IndexOfAny('#', '?');
        if (cut >= 0) body = body[..cut];

        var data = Base64.DecodeFlexible(body);
        JsonObject? obj = null;
        if (data is not null)
        {
            try
            {
                var node = JsonNode.Parse(data) as JsonObject;
                obj = node;
            }
            catch (JsonException) { }
        }
        if (obj is null) throw new ParseErrorException(ParseErrorKind.InvalidBase64);

        string? Str(string key) => obj[key] is JsonValue v && v.TryGetValue<string>(out var s) ? s : null;
        int? IntVal(string key)
        {
            if (obj[key] is not JsonValue v) return null;
            if (v.TryGetValue<int>(out var i)) return i;
            if (v.TryGetValue<string>(out var s) && int.TryParse(s, out var parsed)) return parsed;
            return null;
        }

        var add = Str("add");
        var port = IntVal("port");
        var id = Str("id");
        if (string.IsNullOrEmpty(add) || port is null || port is < 1 or > 65535 || string.IsNullOrEmpty(id))
            throw new ParseErrorException(ParseErrorKind.MissingField, "add/port/id");

        // Panels emit `tls` three ways: string ("tls"/"reality"/"xtls"/"none"),
        // JSON boolean ("tls": true), or absent. Boolean must be checked
        // before Str, or true masquerades as "1".
        string tlsName;
        if (obj["tls"] is JsonValue bv && bv.TryGetValue<bool>(out var b))
            tlsName = b ? "tls" : "none";
        else
            tlsName = (Str("tls") ?? "none").ToLowerInvariant();
        var security = tlsName switch
        {
            "tls" => StreamSecurity.Tls,
            "reality" => StreamSecurity.Reality,
            "xtls" => StreamSecurity.Xtls,
            _ => StreamSecurity.None,
        };
        var net = NetworkTypeOfJson(Str("net"));

        var server = new ProxyServer(
            name: Str("ps") ?? add,
            proto: ProxyProtocol.Vmess,
            address: add,
            port: port.Value,
            credential: id,
            alterId: IntVal("aid") ?? 0,
            network: net,
            security: security,
            vmessCipher: EmptyToNull(Str("scy")),
            sni: EmptyToNull(Str("sni")),
            fingerprint: EmptyToNull(Str("fp")),
            realityPublicKey: EmptyToNull(Str("pbk")),
            realityShortId: EmptyToNull(Str("sid")),
            realitySpiderX: EmptyToNull(Str("spx")),
            path: EmptyToNull(Str("path")),
            host: EmptyToNull(Str("host")),
            headerType: EmptyToNull(Str("type"))
        );
        if (Str("alpn") is { Length: > 0 } alpn)
        {
            server.Alpn = alpn.Split(',').Select(p => p.Trim()).ToList();
        }
        // mode=multi for a gRPC transport never reaches the stream-params path
        // (the vmess JSON carries it as a top-level field, not a query):
        // without this, multi-mode servers failed their handshake silently.
        if (net == NetworkType.Grpc)
        {
            var mode = Str("mode");
            server.GrpcMultiMode = mode is not null && mode.Equals("multi", StringComparison.OrdinalIgnoreCase);
        }
        return server;
    }

    // MARK: - Shadowsocks

    private static ProxyServer ParseShadowsocks(string link)
    {
        // Two encodings exist:
        //   Legacy:  ss://base64(method:password@host:port)#name
        //   SIP002:  ss://base64(method:password)@host:port/?plugin=...#name
        var body = link["ss://".Length..];

        // Peel off #name first.
        string? name = null;
        int hash = body.IndexOf('#');
        if (hash >= 0)
        {
            name = Uri.UnescapeDataString(body[(hash + 1)..]);
            body = body[..hash];
        }

        // Peel off the query and keep it: both encodings can carry parameters
        // (panels append them to legacy links too, where a leftover ?… tail
        // would shift the base64 decode), and the SIP002 branch checks it for
        // a load-bearing plugin.
        string? query = null;
        int qMark = body.IndexOf('?');
        if (qMark >= 0)
        {
            query = body[(qMark + 1)..];
            body = body[..qMark];
        }

        if (body.Contains('@'))
        {
            // SIP002 (userinfo may be base64 or plain).
            if (query is not null)
            {
                // A SIP003 plugin (obfs-local, v2ray-plugin, shadow-tls…) is
                // load-bearing obfuscation: ProxyServer has no field for it,
                // and importing the link as plain Shadowsocks would look
                // healthy, then fail every handshake server-side with no
                // explanation. Fail the parse loudly instead, so the
                // subscription importer reports the real reason.
                foreach (var pair in query.Split('&'))
                {
                    int eq = pair.IndexOf('=');
                    var key = eq > 0 ? pair[..eq] : pair;
                    if (key != "plugin") continue;
                    var rawValue = eq > 0 ? pair[(eq + 1)..] : "";
                    var plugin = TryUnescape(rawValue) ?? rawValue;
                    if (plugin.Length > 0)
                    {
                        var pluginName = plugin.Split(';')[0];
                        throw new ParseErrorException(ParseErrorKind.UnsupportedTransport, $"plugin: {pluginName}");
                    }
                }
            }
            int at = body.LastIndexOf('@');
            if (at < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
            var userInfoRaw = body[..at];
            var hostPort = body[(at + 1)..];

            string userInfo;
            var decoded = Base64.DecodeFlexible(userInfoRaw);
            string? decodedStr = decoded is not null ? Encoding.UTF8.GetString(decoded) : null;
            if (decodedStr is not null && decodedStr.Contains(':'))
            {
                userInfo = decodedStr;
            }
            else
            {
                // SIP002 generators commonly percent-encode the base64
                // userinfo itself (…d29yZA%3D%3D — = padded as %3D, +// as
                // %2B/%2F). The first decode above sees the raw, still-encoded
                // string and fails, so percent-decode FIRST and retry the
                // base64 before falling back to treating it as plain
                // method:password.
                var unescaped = TryUnescape(userInfoRaw) ?? userInfoRaw;
                var retried = Base64.DecodeFlexible(unescaped);
                string? retriedStr = retried is not null ? Encoding.UTF8.GetString(retried) : null;
                userInfo = retriedStr is not null && retriedStr.Contains(':') ? retriedStr : unescaped;
            }
            var (method, password) = SplitMethodPassword(userInfo, link);
            var (host, port) = SplitHostPort(hostPort, link);
            return new ProxyServer(name ?? host, ProxyProtocol.Ss, host, port, password, method: method);
        }
        else
        {
            // Legacy: whole thing is base64(method:password@host:port)
            var decoded = Base64.DecodeFlexible(body);
            var decodedStr = decoded is not null ? Encoding.UTF8.GetString(decoded) : null;
            if (decodedStr is null) throw new ParseErrorException(ParseErrorKind.InvalidBase64);
            int at = decodedStr.LastIndexOf('@');
            if (at < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
            var userInfo = decodedStr[..at];
            var hostPort = decodedStr[(at + 1)..];
            var (method, password) = SplitMethodPassword(userInfo, link);
            var (host, port) = SplitHostPort(hostPort, link);
            return new ProxyServer(name ?? host, ProxyProtocol.Ss, host, port, password, method: method);
        }
    }

    // MARK: - Shared stream-parameter application (VLESS/Trojan)

    /// <summary>Normalize a link's transport name (VLESS/Trojan `type`, VMess
    /// `net`). Real-world links use several aliases for the same transports
    /// (h2 for HTTP/2, kcp for mKCP, raw/websocket for the long names) and
    /// some transports the bundled engine no longer ships (xhttp/splithttp).
    /// A silent .tcp fallback here used to rewire such links into a plain TCP
    /// connection that could never handshake — unknown transports now fail
    /// the parse loudly, so the subscription importer reports the server as
    /// broken instead of connecting nonsense.</summary>
    private static NetworkType NetworkTypeOf(Dictionary<string, string> q) => NetworkTypeOfJson(q.GetValueOrDefault("type"));

    private static NetworkType NetworkTypeOfJson(string? raw)
    {
        var name = (raw ?? "tcp").ToLowerInvariant();
        return name switch
        {
            "" or "tcp" or "raw" or "none" => NetworkType.Tcp,
            "ws" or "websocket" => NetworkType.Ws,
            "grpc" => NetworkType.Grpc,
            "http" or "h2" => NetworkType.Http,
            "httpupgrade" => NetworkType.HttpUpgrade,
            "quic" => NetworkType.Quic,
            "kcp" or "mkcp" => NetworkType.Kcp,
            _ => throw new ParseErrorException(ParseErrorKind.UnsupportedTransport, name),
        };
    }

    private static void ApplyStreamParams(ProxyServer server, Dictionary<string, string> q)
    {
        server.Sni = NonEmpty(q.GetValueOrDefault("sni")) ?? NonEmpty(q.GetValueOrDefault("peer"));
        server.Fingerprint = NonEmpty(q.GetValueOrDefault("fp"));
        server.RealityPublicKey = NonEmpty(q.GetValueOrDefault("pbk"));
        server.RealityShortId = NonEmpty(q.GetValueOrDefault("sid"));
        server.RealitySpiderX = NonEmpty(q.GetValueOrDefault("spx"));
        server.AllowInsecure =
            q.GetValueOrDefault("allowInsecure") == "1" ||
            (q.GetValueOrDefault("allowInsecure")?.ToLowerInvariant() == "true");
        server.HeaderType = NonEmpty(q.GetValueOrDefault("headerType"));
        if (NonEmpty(q.GetValueOrDefault("alpn")) is { } alpn)
        {
            server.Alpn = alpn.Split(',').Select(p => p.Trim()).ToList();
        }
        // gRPC carries serviceName in `path`, the :authority header in `host`
        // and its multiplexing mode in `mode`; ws/http use path + Host header.
        // An *empty* serviceName must be dropped, not preferred: some panels
        // emit serviceName= as a placeholder next to a real path=, and Xray
        // cannot dial gRPC without a service name.
        if (server.Network == NetworkType.Grpc)
        {
            server.Path = NonEmpty(q.GetValueOrDefault("serviceName")) ?? NonEmpty(q.GetValueOrDefault("path"));
            server.Host = NonEmpty(q.GetValueOrDefault("host"));
            server.GrpcMultiMode = q.GetValueOrDefault("mode")?.ToLowerInvariant() == "multi";
        }
        else
        {
            server.Path = NonEmpty(q.GetValueOrDefault("path"));
            server.Host = NonEmpty(q.GetValueOrDefault("host"));
        }
    }

    // MARK: - Small helpers

    private static string? EmptyToNull(string? s) => string.IsNullOrEmpty(s) ? null : s;
    private static string? NonEmpty(string? s) => string.IsNullOrEmpty(s) ? null : s;

    private static string? TryUnescape(string s)
    {
        try { return Uri.UnescapeDataString(s); }
        catch (UriFormatException) { return null; }
    }

    private static (string Method, string Password) SplitMethodPassword(string s, string link)
    {
        int colon = s.IndexOf(':');
        if (colon < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
        return (s[..colon], s[(colon + 1)..]);
    }

    private static (string Host, int Port) SplitHostPort(string s, string link)
    {
        // SIP002 allows (and panels love) a trailing path after the port —
        // ss://b64@host:8388/?plugin=… or even a bare /. The query is already
        // peeled, so anything from the first / onward is transport decoration,
        // not part of the authority. IPv6 literals never contain a slash, so
        // this cut is unambiguous.
        int slash = s.IndexOf('/');
        if (slash >= 0) s = s[..slash];

        // IPv6 in brackets: [::1]:443
        if (s.StartsWith('['))
        {
            int close = s.IndexOf(']');
            if (close < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
            var host = s[1..close];
            var rest = s[(close + 1)..];
            if (!rest.StartsWith(':') || !int.TryParse(rest[1..], out var p6) || p6 is < 1 or > 65535)
                throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
            return (host, p6);
        }
        int colon = s.LastIndexOf(':');
        if (colon < 0 || !int.TryParse(s[(colon + 1)..], out var port) || port is < 1 or > 65535)
            throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
        return (s[..colon], port);
    }
}

/// <summary>Decomposed URI parts for scheme://userInfo@host:port?query#fragment links.</summary>
internal sealed class UriParts
{
    public string? UserInfo { get; }
    public string? Host { get; }
    public int? Port { get; }
    public Dictionary<string, string> Query { get; } = new();
    public string? Fragment { get; }

    public UriParts(string link)
    {
        int schemeEnd = link.IndexOf("://", StringComparison.Ordinal);
        if (schemeEnd < 0) throw new ParseErrorException(ParseErrorKind.MalformedUri, link);
        var rest = link[(schemeEnd + 3)..];

        // Fragment (#name), percent-decoded. A bare # yields no name — an
        // empty string would surface as a blank label in the UI instead of
        // falling back to the host.
        string? frag = null;
        int hash = rest.IndexOf('#');
        if (hash >= 0)
        {
            frag = TryUnescape(rest[(hash + 1)..]);
            rest = rest[..hash];
        }
        Fragment = string.IsNullOrEmpty(frag) ? null : frag;

        // Query string.
        int qMark = rest.IndexOf('?');
        if (qMark >= 0)
        {
            var qStr = rest[(qMark + 1)..];
            rest = rest[..qMark];
            foreach (var pair in qStr.Split('&'))
            {
                int eq = pair.IndexOf('=');
                var key = eq > 0 ? pair[..eq] : pair;
                var value = eq > 0 ? pair[(eq + 1)..] : "";
                Query[key] = TryUnescape(value) ?? value;
            }
        }

        // Authority: userInfo@host:port
        var authority = rest;
        string? user = null;
        int at = authority.LastIndexOf('@');
        if (at >= 0)
        {
            user = TryUnescape(authority[..at]);
            authority = authority[(at + 1)..];
        }
        UserInfo = user;

        // host:port with IPv6 bracket support. A port outside 1…65535 parses
        // fine as an integer but fails the engine's outbound bind at connect
        // time with an opaque error — reject it here, at the source.
        int? PortValue(string s) =>
            int.TryParse(s, out var p) && p is >= 1 and <= 65535 ? p : null;

        if (authority.StartsWith('['))
        {
            int close = authority.IndexOf(']');
            if (close >= 0)
            {
                Host = authority[1..close];
                var tail = authority[(close + 1)..];
                Port = tail.StartsWith(':') ? PortValue(tail[1..]) : null;
                return;
            }
        }
        int colon = authority.LastIndexOf(':');
        if (colon >= 0)
        {
            Host = authority[..colon];
            Port = PortValue(authority[(colon + 1)..]);
        }
        else
        {
            Host = authority.Length == 0 ? null : authority;
            Port = null;
        }
    }

    private static string? TryUnescape(string s)
    {
        try { return Uri.UnescapeDataString(s); }
        catch (UriFormatException) { return null; }
    }
}