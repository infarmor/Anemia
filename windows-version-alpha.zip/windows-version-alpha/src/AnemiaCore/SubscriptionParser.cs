namespace AnemiaCore;

/// <summary>
/// Parses subscription payloads into a list of <see cref="ProxyServer"/>.
/// The common v2ray/xray subscription format is a base64 blob whose decoded
/// text is one share link per line. Some panels serve the links as plain text
/// (already decoded). This handles both, and skips lines it can't parse rather
/// than failing the whole import.
/// </summary>
public static class SubscriptionParser
{
    public sealed record SubscriptionResult(List<ProxyServer> Servers, List<(string Line, ParseErrorException Error)> Failures);

    /// <summary>Parse a raw subscription body (as fetched from a subscription
    /// URL, or pasted by the user).</summary>
    public static SubscriptionResult Parse(string body)
    {
        var trimmed = body.Trim();
        if (trimmed.Length == 0) return new SubscriptionResult(new List<ProxyServer>(), new List<(string, ParseErrorException)>());

        // If the body looks like a single base64 blob (no scheme markers and
        // no newlines), decode it first.
        var text = !trimmed.Contains("://") ? Base64.DecodeToString(trimmed) ?? trimmed : trimmed;

        var servers = new List<ProxyServer>();
        var failures = new List<(string, ParseErrorException)>();

        foreach (var rawLine in text.Split(new[] { '\n', '\r' }))
        {
            var line = rawLine.Trim();
            if (line.Length == 0 || !line.Contains("://")) continue;
            try
            {
                servers.Add(ShareLinkParser.Parse(line));
            }
            catch (ParseErrorException e)
            {
                failures.Add((line, e));
            }
            catch (Exception e)
            {
                failures.Add((line, new ParseErrorException(ParseErrorKind.MalformedUri, e.Message)));
            }
        }

        return new SubscriptionResult(servers, failures);
    }
}

/// <summary>
/// A saved subscription: a URL that returns a list of share links, plus the
/// servers most recently fetched from it.
/// </summary>
public sealed class Subscription
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string Url { get; set; } = "";
    public DateTimeOffset? LastUpdated { get; set; }
    public List<ProxyServer> Servers { get; set; } = new();

    public Subscription() { }

    public Subscription(string name, string url, DateTimeOffset? lastUpdated = null, List<ProxyServer>? servers = null)
    {
        Name = name;
        Url = url;
        LastUpdated = lastUpdated;
        Servers = servers ?? new List<ProxyServer>();
    }
}