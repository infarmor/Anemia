using System.Text;

namespace AnemiaCore;

/// <summary>
/// Base64 decoding that tolerates the sloppy variants seen in proxy share
/// links and subscriptions: URL-safe alphabet (-_) and missing = padding.
/// </summary>
public static class Base64
{
    /// <summary>Decode standard or URL-safe base64, with or without padding.</summary>
    public static byte[]? DecodeFlexible(string input)
    {
        var s = input.Trim();
        if (s.Length == 0) return null;

        // Normalize URL-safe alphabet to standard. Gate the rewrite on an
        // actual URL-safe character so the common (standard-alphabet) path
        // skips the copies.
        if (s.Contains('-') || s.Contains('_'))
        {
            s = s.Replace('-', '+').Replace('_', '/');
        }

        // Restore padding to a multiple of 4.
        int remainder = s.Length % 4;
        if (remainder > 0) s = s.PadRight(s.Length + (4 - remainder), '=');

        try
        {
            return Convert.FromBase64String(s);
        }
        catch (FormatException)
        {
            return null;
        }
    }

    /// <summary>Decode flexible base64 to a UTF-8 string, if valid.</summary>
    public static string? DecodeToString(string input)
    {
        var data = DecodeFlexible(input);
        return data is null ? null : Encoding.UTF8.GetString(data);
    }
}