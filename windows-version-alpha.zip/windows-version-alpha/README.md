# Anemia for Windows

Windows port of the macOS **Anemia** (Loader) VPN client: an Xray-core
wrapper with anti-DPI features — Reality / XTLS-Vision, TLS ClientHello
fragmentation, junk-noise packets, and stealth-SNI mimicry tuned against
Russian TSPU inspection.

Same engine (Xray-core), same share-link surface (vless / vmess / ss /
trojan, all transports), same anti-censorship profiles — rebuilt in C#
so the whole core is unit-tested and cross-buildable from any host.

## UI

The WPF window mirrors the macOS RootView design (warm Claude theme,
ported from `Theme.swift` — ivory/charcoal gradient, terracotta accent,
serif display type, soft-shadow card tiles). Top bar carries the brand,
the status cluster (lamp · status · session timer · latency · live
throughput), the connect switch and settings; below it the server card
(opens the server picker sheet), Fastest/Ping actions, a one-tile
traffic readout, the protection tile (kill switch / DPI masking /
traffic mode) and the log tail. Light and dark palettes are both
first-class and follow the system appearance live. The tray icon
exposes the same connect toggle and a fast server submenu.

## Layout

| Project | Role | macOS analogue |
|---|---|---|
| `src/AnemiaCore` | Parsers, config builder, stats API, persistence — pure .NET, fully unit-tested | `LoaderCore` + `LoaderShared` |
| `src/AnemiaApp` | WPF window + tray icon, connection state machine, system proxy | `LoaderApp` |
| `src/AnemiaHelper` | Elevated tunnel supervisor: tun2socks/wintun, routes, firewall kill switch | `LoaderHelper` + `LoaderTool` |
| `tests/AnemiaCoreTests` | 85 xunit tests ported from the Swift test suite | — |

The app runs **unprivileged** (asInvoker). Privileged work — the wintun
adapter, the route table, the fail-closed firewall policy — happens in
`AnemiaHelper`, launched elevated (one UAC prompt) over a named-pipe
JSON channel the first time a TUN tunnel is requested.

## Building

Any .NET 8 SDK, any host (macOS/Linux cross-build the WPF binaries via
`EnableWindowsTargeting`; only *running* needs Windows):

```sh
dotnet build Anemia.sln
dotnet test  tests/AnemiaCoreTests/AnemiaCoreTests.csproj
```

Production publish (both binaries land side by side, which is what the
helper expects, with native cores copied in from `Resources\`):

```powershell
powershell -ExecutionPolicy Bypass -File Scripts\publish.ps1            # win-x64
powershell -ExecutionPolicy Bypass -File Scripts\publish.ps1 -SelfContained
```

## Native dependencies

`Scripts/fetch-cores.ps1` downloads and SHA256-pins into `Resources\`:

- `xray.exe` — Xray-core (the engine)
- `tun2socks.exe` — xjasonlyu/tun2socks (owns the wintun adapter in TUN mode)
- `wintun.dll` — loaded by tun2socks at runtime

The first `xray` run per config shape is validated with `xray run -test`
before launch; verdicts are cached per (server, anti-DPI shape) for the
session.

## What's ported, and the invariants kept

- **Share links**: vless/vmess/ss (SIP002 + legacy)/trojan, transport
  aliases (`h2`, `kcp`, `raw`, `websocket`), Reality params, gRPC
  `mode=multi`. Removed transports (xhttp) and SIP003 plugins fail loudly.
- **Anti-DPI profiles**: Off / Balanced / Maximum / RU·Yandex / RU·VK —
  fragment + noise + mimicry settings byte-identical to the Swift build.
  On engine-level connect failures the client **escalates** up the ladder
  and remembers the learned profile per server (`LearnedMasking`).
- **Invariants preserved** (all covered by tests):
  - never emit `tcpFastOpen` (Xray-core #989 — EINVAL on dial);
  - always emit the `tcpKeepAliveIdle=30` + `tcpKeepAliveInterval=10` pair;
  - never emit `allowInsecure` (removed in Xray 26.x);
  - mimicry stealth-SNI only for Reality, never plain TLS;
  - mux disabled under XTLS-Vision;
  - DNS: DoH through the proxy + the server's own domain pinned in
    `dns.hosts`, so resolving the server never loops through the tunnel;
  - QUIC blocked at the routing layer (TCP is the path the obfuscation
    actually secures).
- **Traffic stats**: native gRPC-over-h2c `StatsService.QueryStats`
  client, with an `xray api statsquery` CLI fallback.
- **Reliability**: free-port picks before bind, readiness gate (SOCKS
  port must answer *and* the process must still be alive), stale-run
  guards on stop/start races, exponential-backoff auto-reconnect,
  history store with corrupt-backup + salvage decoding.
- **Failover**: three consecutive failed end-to-end health checks
  (~1 min of a "working" but dead tunnel) force a reconnect through the
  same ladder as a crash — including masking escalation.
- **Server ranking**: replacement for the macOS CoreML ranker — median of
  recent handshake history (⅔) blended with a fresh probe (⅓); the tray's
  **Servers** submenu fast-switches, and auto-connect with no explicit
  selection picks the best-ranked server.
- **Subscriptions**: auto-refresh on launch and every 6 h when the flag
  is on; refreshes preserve identity keys, so selection and ping history
  survive updates.

## TUN mode & kill switch

When the kill switch (or TUN routing) is on, the helper:

1. flips the firewall to **default-deny outbound** in all profiles
   (fail-closed — the seal exists before any exception does);
2. allows only loopback, `xray.exe` / `tun2socks.exe` / `Anemia.exe`,
   DHCP renewals, and the VPN server's IP (the /32 bypass);
3. spawns tun2socks on device `anemia`, addresses it `198.18.0.1/24`,
   routes default via `198.18.0.2` and the server's /32 via the
   *original* gateway;
4. points system DNS at the tunnel (the engine hijacks :53 → DoH).

Teardown is the reverse and idempotent; the helper also repairs
crash-orphaned state on every boot.

## Proxy-only mode

Without the helper (UAC declined, binary missing), the client falls back
to a plain local proxy: SOCKS `127.0.0.1:10808`, HTTP `127.0.0.1:10809`,
optionally set as the system proxy via WinINet — always cleared on
disconnect, never left stale.

## State

`%APPDATA%\Anemia\state.json` (servers, subscriptions, selection,
masking profile, learned masking) and `history.json` (ping history,
rolling 256 samples per server). Malformed state is salvaged entry-wise
and backed up as `.corrupt-<ts>.bak` before reset.